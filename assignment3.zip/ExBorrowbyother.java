public class ExBorrowbyother extends Exception{
    public ExBorrowbyother() { super("Borrowed by others"); }
    public ExBorrowbyother(String message) { super(message); }
}