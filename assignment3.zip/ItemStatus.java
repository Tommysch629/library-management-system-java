public interface  ItemStatus 
{
	public String getNameAndId(Member member,Day loanDate);
	public String getStatus ();
	public String b_person();
	public Day b_day();
	public String real_getStatus ();
}