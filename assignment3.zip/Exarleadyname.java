public class Exarleadyname extends Exception{
    public Exarleadyname() { super("ID already used"); }
    public Exarleadyname(String message) { super(message); }
}
