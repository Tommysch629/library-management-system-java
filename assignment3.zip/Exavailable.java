public class Exavailable extends Exception{
    public Exavailable() { super("It is available"); }
    public Exavailable(String message) { super(message); }
}
