public class Exborrowedbyyou extends Exception{
    public Exborrowedbyyou() { super("You borrowed"); }
    public Exborrowedbyyou(String message) { super(message); }
}