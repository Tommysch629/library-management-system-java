public class Exall extends Exception{
    public Exall() { super("There has a error!"); }
    public Exall(String message) { super(message); }
}
