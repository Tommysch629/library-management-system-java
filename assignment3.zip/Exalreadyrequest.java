public class Exalreadyrequest extends Exception{
    public Exalreadyrequest() { super("Alredy request"); }
    public Exalreadyrequest(String message) { super(message); }
}
